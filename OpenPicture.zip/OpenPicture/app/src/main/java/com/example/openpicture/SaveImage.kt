package com.example.openpicture

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

object SaveImage{
     val IMAGE_DIRECTORY="/MyFolderCamera"
    var f:File?=null
    public fun saveImage(myBitmap: Bitmap,context:Context): File {
        val bytes = ByteArrayOutputStream()
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val wallpaperDirectory = File(
                (Environment.getExternalStorageDirectory()).toString() + IMAGE_DIRECTORY
        )
        // have the object build the directory structure, if needed.
        Log.d("fee", wallpaperDirectory.toString())
        if (!wallpaperDirectory.exists()) {

            wallpaperDirectory.mkdirs()
        }

        try {
            Log.d("heel", wallpaperDirectory.toString())
             f = File(
                    wallpaperDirectory, ((Calendar.getInstance()
                    .timeInMillis).toString() + ".jpg")
            )
            f?.createNewFile()
            val fo = FileOutputStream(f)
            fo.write(bytes.toByteArray())
            MediaScannerConnection.scanFile(
                    context,
                    arrayOf(f?.path),
                    arrayOf("image/jpeg"), null
            )
            fo.close()
            Log.d("tag", "File Saved::--->" + f?.absolutePath)

            return f as File
        } catch (e1: IOException) {
            e1.printStackTrace()
        }

        return f as File
    }

}