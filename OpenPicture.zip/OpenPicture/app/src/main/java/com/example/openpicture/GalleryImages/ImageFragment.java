package com.example.openpicture.GalleryImages;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.openpicture.R;
import com.example.openpicture.zoomEffect.ZoomableImageView;


public class ImageFragment extends Fragment {
    String imagePAth;
    private static final String TAG = "ImageFragment";

    public ImageFragment(String s) {
        imagePAth = s;
        Log.e(TAG, "ImageFragment: " + s);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ZoomableImageView imageView = view.findViewById(R.id.image);
        Bitmap yourbitmap = BitmapFactory.decodeFile(imagePAth);
//        Bitmap resized = Bitmap.createScaledBitmap(yourbitmap, 200, 300, true);
        imageView.setImageBitmap(yourbitmap);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_image, container, false);
    }
}