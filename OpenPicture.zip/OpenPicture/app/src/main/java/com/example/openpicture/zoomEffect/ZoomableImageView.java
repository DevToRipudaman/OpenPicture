package com.example.openpicture.zoomEffect;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.example.openpicture.R;

@SuppressLint("AppCompatCustomView")
public class ZoomableImageView extends ImageView implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {
//    Matrix matrix = new Matrix();
//
//    static final int NONE = 0;
//    static final int DRAG = 1;
//    static final int ZOOM = 2;
//    static final int CLICK = 3;
//    int mode = NONE;
//
//    PointF last = new PointF();
//    PointF start = new PointF();
//    float minScale = 1f;
//    float maxScale = 4f;
//    float[] m;
//
//    float redundantXSpace, redundantYSpace;
//    float width, height;
//    float saveScale = 1f;
//    float right, bottom, origWidth, origHeight, bmWidth, bmHeight;
//
//    ScaleGestureDetector mScaleDetector;
//    Context context;
//
//    public ZoomableImageView(Context context, AttributeSet attr)
//    {
//        super(context, attr);
//        super.setClickable(true);
//        this.context = context;
//        mScaleDetector = new ScaleGestureDetector(context, new ScaleListener());
//        matrix.setTranslate(1f, 1f);
//        m = new float[9];
//        setImageMatrix(matrix);
//        setScaleType(ScaleType.MATRIX);
//
//        setOnTouchListener(new OnTouchListener()
//        {
//
//
//            @Override
//            public boolean onTouch(View v, MotionEvent event)
//            {
//                mScaleDetector.onTouchEvent(event);
//
//                matrix.getValues(m);
//                float x = m[Matrix.MTRANS_X];
//                float y = m[Matrix.MTRANS_Y];
//                PointF curr = new PointF(event.getX(), event.getY());
//
//                switch (event.getAction())
//                {
//                    //when one finger is touching
//                    //set the mode to DRAG
//                    case MotionEvent.ACTION_DOWN:
//                        last.set(event.getX(), event.getY());
//                        start.set(last);
//                        mode = DRAG;
//                        break;
//                    //when two fingers are touching
//                    //set the mode to ZOOM
//                    case MotionEvent.ACTION_POINTER_DOWN:
//                        last.set(event.getX(), event.getY());
//                        start.set(last);
//                        mode = ZOOM;
//                        break;
//                    //when a finger moves
//                    //If mode is applicable move image
//                    case MotionEvent.ACTION_MOVE:
//                        //if the mode is ZOOM or
//                        //if the mode is DRAG and already zoomed
//                        if (mode == ZOOM || (mode == DRAG && saveScale > minScale))
//                        {
//                            float deltaX = curr.x - last.x;// x difference
//                            float deltaY = curr.y - last.y;// y difference
//                            float scaleWidth = Math.round(origWidth * saveScale);// width after applying current scale
//                            float scaleHeight = Math.round(origHeight * saveScale);// height after applying current scale
//                            //if scaleWidth is smaller than the views width
//                            //in other words if the image width fits in the view
//                            //limit left and right movement
//                            if (scaleWidth < width)
//                            {
//                                deltaX = 0;
//                                if (y + deltaY > 0)
//                                    deltaY = -y;
//                                else if (y + deltaY < -bottom)
//                                    deltaY = -(y + bottom);
//                            }
//                            //if scaleHeight is smaller than the views height
//                            //in other words if the image height fits in the view
//                            //limit up and down movement
//                            else if (scaleHeight < height)
//                            {
//                                deltaY = 0;
//                                if (x + deltaX > 0)
//                                    deltaX = -x;
//                                else if (x + deltaX < -right)
//                                    deltaX = -(x + right);
//                            }
//                            //if the image doesnt fit in the width or height
//                            //limit both up and down and left and right
//                            else
//                            {
//                                if (x + deltaX > 0)
//                                    deltaX = -x;
//                                else if (x + deltaX < -right)
//                                    deltaX = -(x + right);
//
//                                if (y + deltaY > 0)
//                                    deltaY = -y;
//                                else if (y + deltaY < -bottom)
//                                    deltaY = -(y + bottom);
//                            }
//                            //move the image with the matrix
//                            matrix.postTranslate(deltaX, deltaY);
//                            //set the last touch location to the current
//                            last.set(curr.x, curr.y);
//                        }
//                        break;
//                    //first finger is lifted
//                    case MotionEvent.ACTION_UP:
//                        mode = NONE;
//                        int xDiff = (int) Math.abs(curr.x - start.x);
//                        int yDiff = (int) Math.abs(curr.y - start.y);
//                        if (xDiff < CLICK && yDiff < CLICK)
//                            performClick();
//                        break;
//                    // second finger is lifted
//                    case MotionEvent.ACTION_POINTER_UP:
//                        mode = NONE;
//                        break;
//
//                }
//                setImageMatrix(matrix);
//                invalidate();
//                return true;
//            }
//
//        });
//    }
//
//    @Override
//    public void setImageBitmap(Bitmap bm)
//    {
//        super.setImageBitmap(bm);
//        bmWidth = bm.getWidth();
//        bmHeight = bm.getHeight();
//    }
//
//    public void setMaxZoom(float x)
//    {
//        maxScale = x;
//    }
//
//    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener
//    {
//
//        @Override
//        public boolean onScaleBegin(ScaleGestureDetector detector)
//        {
//            mode = ZOOM;
//            return true;
//        }
//
//        @Override
//        public boolean onScale(ScaleGestureDetector detector)
//        {
//            float mScaleFactor = detector.getScaleFactor();
//            float origScale = saveScale;
//            saveScale *= mScaleFactor;
//            if (saveScale > maxScale)
//            {
//                saveScale = maxScale;
//                mScaleFactor = maxScale / origScale;
//            }
//            else if (saveScale < minScale)
//            {
//                saveScale = minScale;
//                mScaleFactor = minScale / origScale;
//            }
//            right = width * saveScale - width - (2 * redundantXSpace * saveScale);
//            bottom = height * saveScale - height - (2 * redundantYSpace * saveScale);
//            if (origWidth * saveScale <= width || origHeight * saveScale <= height)
//            {
//                matrix.postScale(mScaleFactor, mScaleFactor, width / 2, height / 2);
//                if (mScaleFactor < 1)
//                {
//                    matrix.getValues(m);
//                    float x = m[Matrix.MTRANS_X];
//                    float y = m[Matrix.MTRANS_Y];
//                    if (mScaleFactor < 1)
//                    {
//                        if (Math.round(origWidth * saveScale) < width)
//                        {
//                            if (y < -bottom)
//                                matrix.postTranslate(0, -(y + bottom));
//                            else if (y > 0)
//                                matrix.postTranslate(0, -y);
//                        }
//                        else
//                        {
//                            if (x < -right)
//                                matrix.postTranslate(-(x + right), 0);
//                            else if (x > 0)
//                                matrix.postTranslate(-x, 0);
//                        }
//                    }
//                }
//            }
//            else
//            {
//                matrix.postScale(mScaleFactor, mScaleFactor, detector.getFocusX(), detector.getFocusY());
//                matrix.getValues(m);
//                float x = m[Matrix.MTRANS_X];
//                float y = m[Matrix.MTRANS_Y];
//                if (mScaleFactor < 1) {
//                    if (x < -right)
//                        matrix.postTranslate(-(x + right), 0);
//                    else if (x > 0)
//                        matrix.postTranslate(-x, 0);
//                    if (y < -bottom)
//                        matrix.postTranslate(0, -(y + bottom));
//                    else if (y > 0)
//                        matrix.postTranslate(0, -y);
//                }
//            }
//            return true;
//        }
//    }
//
//    @Override
//    protected void onMeasure (int widthMeasureSpec, int heightMeasureSpec)
//    {
//        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
//        width = MeasureSpec.getSize(widthMeasureSpec);
//        height = View.MeasureSpec.getSize(heightMeasureSpec);
//        //Fit to screen.
//        float scale;
//        float scaleX =  width / bmWidth;
//        float scaleY = height / bmHeight;
//        scale = Math.min(scaleX, scaleY);
//        matrix.setScale(scale, scale);
//        setImageMatrix(matrix);
//        saveScale = 1f;
//
//        // Center the image
//        redundantYSpace = height - (scale * bmHeight) ;
//        redundantXSpace = width - (scale * bmWidth);
//        redundantYSpace /= 2;
//        redundantXSpace /= 2;
//
//        matrix.postTranslate(redundantXSpace, redundantYSpace);
//
//        origWidth = width - 2 * redundantXSpace;
//        origHeight = height - 2 * redundantYSpace;
//        right = width * saveScale - width - (2 * redundantXSpace * saveScale);
//        bottom = height * saveScale - height - (2 * redundantYSpace * saveScale);
//        setImageMatrix(matrix);
//    }

    Matrix matrix;

    // We can be in one of these 3 states
    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;

    // Remember some things for zooming
    PointF last = new PointF();
    PointF start = new PointF();
    float minScale = 1f;
    float maxScale = 3f;
    float[] m;

    int viewWidth, viewHeight;
    static final int CLICK = 3;
    float saveScale = 1f;
    protected float origWidth, origHeight;
    int oldMeasuredWidth, oldMeasuredHeight;

    ScaleGestureDetector mScaleDetector;

    Context context;

    public ZoomableImageView(Context context) {
        super(context);
        sharedConstructing(context);
    }

    public ZoomableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        sharedConstructing(context);
    }

    GestureDetector mGestureDetector;

    private void sharedConstructing(Context context) {
        super.setClickable(true);
        this.context = context;
        mGestureDetector = new GestureDetector(context, this);
        mGestureDetector.setOnDoubleTapListener(this);

        mScaleDetector = new ScaleGestureDetector(context, new ScaleListener());
        matrix = new Matrix();
        m = new float[9];
        setImageMatrix(matrix);
        setScaleType(ScaleType.MATRIX);

        setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mScaleDetector.onTouchEvent(event);
                mGestureDetector.onTouchEvent(event);

                PointF curr = new PointF(event.getX(), event.getY());

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        last.set(curr);
                        start.set(last);
                        mode = DRAG;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        if (mode == DRAG) {
                            float deltaX = curr.x - last.x;
                            float deltaY = curr.y - last.y;
                            float fixTransX = getFixDragTrans(deltaX, viewWidth,
                                    origWidth * saveScale);
                            float fixTransY = getFixDragTrans(deltaY, viewHeight,
                                    origHeight * saveScale);
                            matrix.postTranslate(fixTransX, fixTransY);
                            fixTrans();
                            last.set(curr.x, curr.y);
                        }
                        break;

                    case MotionEvent.ACTION_UP:
                        mode = NONE;
                        int xDiff = (int) Math.abs(curr.x - start.x);
                        int yDiff = (int) Math.abs(curr.y - start.y);
                        if (xDiff < CLICK && yDiff < CLICK)
                            performClick();
                        break;

                    case MotionEvent.ACTION_POINTER_UP:
                        mode = NONE;
                        break;
                }

                setImageMatrix(matrix);
                invalidate();
                return true; // indicate event was handled
            }

        });
    }

    public void setMaxZoom(float x) {
        maxScale = x;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        // Double tap is detected
        Log.i("MAIN_TAG", "Double tap detected");
        float origScale = saveScale;
        float mScaleFactor;

        if (saveScale == maxScale) {
            saveScale = minScale;
            mScaleFactor = minScale / origScale;
        } else {
            saveScale = maxScale;
            mScaleFactor = maxScale / origScale;
        }

        matrix.postScale(mScaleFactor, mScaleFactor, viewWidth / 2,
                viewHeight / 2);

        fixTrans();
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    private class ScaleListener extends
            ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector) {
            mode = ZOOM;
            return true;
        }

        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float mScaleFactor = detector.getScaleFactor();
            float origScale = saveScale;
            saveScale *= mScaleFactor;
            if (saveScale > maxScale) {
                saveScale = maxScale;
                mScaleFactor = maxScale / origScale;
            } else if (saveScale < minScale) {
                saveScale = minScale;
                mScaleFactor = minScale / origScale;
            }

            if (origWidth * saveScale <= viewWidth
                    || origHeight * saveScale <= viewHeight)
                matrix.postScale(mScaleFactor, mScaleFactor, viewWidth / 2,
                        viewHeight / 2);
            else
                matrix.postScale(mScaleFactor, mScaleFactor,
                        detector.getFocusX(), detector.getFocusY());

            fixTrans();
            return true;
        }
    }

    void fixTrans() {
        matrix.getValues(m);
        float transX = m[Matrix.MTRANS_X];
        float transY = m[Matrix.MTRANS_Y];

        float fixTransX = getFixTrans(transX, viewWidth, origWidth * saveScale);
        float fixTransY = getFixTrans(transY, viewHeight, origHeight
                * saveScale);

        if (fixTransX != 0 || fixTransY != 0)
            matrix.postTranslate(fixTransX, fixTransY);
    }

    float getFixTrans(float trans, float viewSize, float contentSize) {
        float minTrans, maxTrans;

        if (contentSize <= viewSize) {
            minTrans = 0;
            maxTrans = viewSize - contentSize;
        } else {
            minTrans = viewSize - contentSize;
            maxTrans = 0;
        }

        if (trans < minTrans)
            return -trans + minTrans;
        if (trans > maxTrans)
            return -trans + maxTrans;
        return 0;
    }

    float getFixDragTrans(float delta, float viewSize, float contentSize) {
        if (contentSize <= viewSize) {
            return 0;
        }
        return delta;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        viewWidth = MeasureSpec.getSize(widthMeasureSpec);
        viewHeight = MeasureSpec.getSize(heightMeasureSpec);

        //
        // Rescales image on rotation
        //
        if (oldMeasuredHeight == viewWidth && oldMeasuredHeight == viewHeight
                || viewWidth == 0 || viewHeight == 0)
            return;
        oldMeasuredHeight = viewHeight;
        oldMeasuredWidth = viewWidth;

        if (saveScale == 1) {
            // Fit to screen.
            float scale;

            Drawable drawable = getDrawable();
            if (drawable == null || drawable.getIntrinsicWidth() == 0
                    || drawable.getIntrinsicHeight() == 0)
                return;
            int bmWidth = drawable.getIntrinsicWidth();
            int bmHeight = drawable.getIntrinsicHeight();

            Log.d("bmSize", "bmWidth: " + bmWidth + " bmHeight : " + bmHeight);

            float scaleX = (float) viewWidth / (float) bmWidth;
            float scaleY = (float) viewHeight / (float) bmHeight;
            scale = Math.min(scaleX, scaleY);
            matrix.setScale(scale, scale);

            // Center the image
            float redundantYSpace = (float) viewHeight
                    - (scale * (float) bmHeight);
            float redundantXSpace = (float) viewWidth
                    - (scale * (float) bmWidth);
            redundantYSpace /= (float) 2;
            redundantXSpace /= (float) 2;

            matrix.postTranslate(redundantXSpace, redundantYSpace);

            origWidth = viewWidth - 2 * redundantXSpace;
            origHeight = viewHeight - 2 * redundantYSpace;
            setImageMatrix(matrix);
        }
        fixTrans();
    }
}