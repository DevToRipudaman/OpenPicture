package com.example.openpicture.GalleryImages;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;

import com.example.openpicture.R;
import com.example.openpicture.ViewPageAdapter;

import java.io.IOException;
import java.util.ArrayList;

public class ImageActivity extends AppCompatActivity {
    ViewPager viewPager;
    ArrayList<String> images;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        viewPager = findViewById(R.id.viewPager);

        getBundle();
    }

    private void getBundle() {
        if (getIntent().hasExtra("picture")) {
            images = getIntent().getStringArrayListExtra("picture");
            viewPager.setAdapter(new ViewPageAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT, images));
        }
    }

}