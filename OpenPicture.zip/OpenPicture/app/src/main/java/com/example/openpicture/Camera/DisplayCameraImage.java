package com.example.openpicture.Camera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.openpicture.R;
import com.example.openpicture.SaveImage;
import com.example.openpicture.zoomEffect.ZoomableImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DisplayCameraImage extends AppCompatActivity {

    ZoomableImageView imageView;
    BitmapDrawable drawable;
    Bitmap bitmap;
    String currentPhotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_camera_image);
        imageView = findViewById(R.id.image_camera);
        getBundle();
        drawable = (BitmapDrawable) imageView.getDrawable();
        bitmap = drawable.getBitmap();   // we got the image from bitmap and drawable
        File file = SaveImage.INSTANCE.saveImage(bitmap, this);
        Toast toast = Toast.makeText(this, "Image Saved Successfully!", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();

        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);  // to tell the media so that it can scan.
        Uri contentUri = Uri.fromFile(file);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);

     /*   FileOutputStream outputStream;

        File sdCard = Environment.getExternalStorageDirectory();
        //whatever is the directory we will create here
        File directory = new File(sdCard.getAbsolutePath() + "/MyFolderCamera");
        if (!directory.exists()){

            directory.mkdir();   //this will create the directory with that name.
        }
        String fileName = String.format( "%d.jpg",System.currentTimeMillis()); //saving image with extension .jpg
        File outFile = new File(directory,fileName);


        try {
            outFile.createNewFile();
            outputStream = new FileOutputStream(outFile);
            ByteArrayOutputStream bytes =new  ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,bytes);
            outputStream.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(
                    this,
                   new  String[]{outFile.getPath()},
                    new String[]{"image/jpeg"}, null
            );
            outputStream.close();



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    private void getBundle() {
        Bitmap bitmap = BitmapFactory.decodeFile(getIntent().getStringExtra("image_path"));
        imageView.setImageBitmap(bitmap);


    }
}